<?php
$host = "localhost";
$dbusername = "root";
$dbpassword = ""; // Assuming empty password
$dbdatabase = "crime_management";

// Create connection
$conn = new mysqli($host, $dbusername, $dbpassword, $dbdatabase);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assuming you're using POST method to send data
$Name = $_POST['Name'] ?? '';
$Password = $_POST['Password'] ?? '';

// Prepare SQL statement to prevent SQL injection
$sql = $conn->prepare("INSERT INTO user_login (Name, Password) VALUES (?, ?)");

// Bind parameters and execute query
$sql->bind_param("ss", $Name, $Password);

if ($sql->execute()) {
    // Close PHP tag to insert JavaScript code
    ?>
    <script>
        // Display popup message
        alert("Login successful!");
        // Redirect to user home page
        window.location.href = "userhome.html";
    </script>
    <?php
    exit(); // Make sure to exit after redirection
} else {
    echo "Error: " . $sql->error;
}

// Close connection
$conn->close();
?>
