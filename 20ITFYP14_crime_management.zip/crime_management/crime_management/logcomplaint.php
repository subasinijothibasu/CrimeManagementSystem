<?php
$host = "localhost";
$dbusername = "root";
$dbpassword = ""; // Assuming empty password
$dbdatabase = "crime_management";

// Create connection
$conn = new mysqli($host, $dbusername, $dbpassword, $dbdatabase);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Assuming you're using POST method to send data
$name = $_POST['name'] ?? '';
$aadhar = $_POST['aadhar'] ?? '';
$location = $_POST['location'] ?? '';
$crime_type = $_POST['crime_type'] ?? '';
$date = $_POST['date'] ?? '';
$description = $_POST['description'] ?? '';

// Prepare SQL statement to prevent SQL injection
$sql = $conn->prepare("INSERT INTO log_complaint (name, aadhar, location, crime_type, date, description) VALUES (?, ?, ?, ?, ?, ?)");

// Bind parameters and execute query
$sql->bind_param("ssssss", $name, $aadhar, $location, $crime_type, $date, $description);

if ($sql->execute()) {
  // Close PHP tag to insert JavaScript code
  ?>
  <script>
    // Display popup message
    alert("Thank You! Your investigation request has been submitted successfully.");
    // Redirect to complaint history page after a short delay
    setTimeout(function() {
      window.location.href = "complaint_history.php";
    }, 2000); // Delay in milliseconds (2000ms = 2 seconds)
  </script>
  <?php
} else {
  echo "Error: " . $sql->error;
}

// Close connection
$conn->close();
?>
