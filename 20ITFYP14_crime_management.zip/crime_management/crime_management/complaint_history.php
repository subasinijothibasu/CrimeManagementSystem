<?php
$host = "localhost";
$dbusername = "root";
$dbpassword = ""; // Assuming empty password
$dbdatabase = "crime_management";

// Create connection
$conn = new mysqli($host, $dbusername, $dbpassword, $dbdatabase);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch data
$sql = "SELECT * FROM log_complaint";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reports</title>
    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }
        table {
            margin: 0 auto;
            font-size: large;
            border: 1px solid black;
        }
        td {
            background-color: #E4F5D4;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
        th, td {
            font-weight: bold;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
        td {
            font-weight: lighter;
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="images/logo.png" alt="logo">
        <h2>Complaint History</h2>
    </div>
    <table>
        <tr>
            <th>Name</th>
            <th>Aadhar</th>
            <th>Location</th>
            <th>Crime Type</th>
            <th>Date</th>
            <th>Description</th>
        </tr>
        <?php 
        // LOOP TILL END OF DATA
        while($row = $result->fetch_assoc()) {
        ?>
        <tr>
            <!-- FETCHING DATA FROM EACH ROW OF EVERY COLUMN -->
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['aadhar']; ?></td>
            <td><?php echo $row['location']; ?></td>
            <td><?php echo $row['crime_type']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['description']; ?></td>
        </tr>
        <?php
        }
        ?>
    </table>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
