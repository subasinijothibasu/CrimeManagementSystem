<?php
$host = "localhost";
$dbusername = "root";
$dbpassword = ""; // Assuming empty password
$dbdatabase = "crime_management";

// Create connection
$conn = new mysqli($host, $dbusername, $dbpassword, $dbdatabase);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Assuming you're using POST method to send data
$name = $_POST['name'] ?? '';
$contact = $_POST['contact'] ?? '';
$designation = $_POST['designation'] ?? '';
$branch = $_POST['branch'] ?? '';
$location = $_POST['location'] ?? '';
$city = $_POST['city'] ?? '';
$state = $_POST['state'] ?? '';
$password = $_POST['password'] ??'';
$confirm_password = $_POST['confirm_password'] ??'';


// Prepare SQL statement to prevent SQL injection
$sql = $conn->prepare("INSERT INTO police_signup (name, contact, designation, branch, location, city, state, password, confirm_password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

// Bind parameters and execute query
$sql->bind_param("sssssssss", $name, $contact, $designation,$branch,$location,$city,$state,$password,$confirm_password);

if ($sql->execute()) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql->error;
}

// Close connection
$conn->close();
?>
