<?php
$host = "localhost";
$dbusername = "root";
$dbpassword = ""; // Assuming empty password
$dbdatabase = "crime_management";

// Create connection
$conn = new mysqli($host, $dbusername, $dbpassword, $dbdatabase);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch data from action_taken table
$sql = "SELECT * FROM action_taken";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Action Taken Reports</title>
    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }
        table {
            margin: 0 auto;
            font-size: large;
            border: 1px solid black;
        }
        td {
            background-color: #E4F5D4;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
        th, td {
            font-weight: bold;
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
        td {
            font-weight: lighter;
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="images/logo.png" alt="logo">
        <h2>Action Taken Reports</h2>
    </div>
    <table>
        <tr>
            <th>Case Number</th>
            <th>Nearest Police Station</th>
            <th>Evidence</th>
            <th>Image Upload</th>
            <th>Video Upload</th>
            <th>Additional Information</th>
            <th>Action Taken</th>
            <th>Police Officer Name</th>
            <th>Station</th>
            <th>Designation</th>
            <th>Status</th>
        </tr>
        <?php 
        // LOOP TILL END OF DATA
        while($row = $result->fetch_assoc()) {
        ?>
        <tr>
            <!-- FETCHING DATA FROM EACH ROW OF EVERY COLUMN -->
            <td><?php echo $row['caseNumber']; ?></td>
            <td><?php echo $row['policeStation']; ?></td>
            <td><?php echo $row['evidence']; ?></td>
            <td><?php echo $row['imageUpload']; ?></td>
            <td><?php echo $row['videoUpload']; ?></td>
            <td><?php echo $row['additionalInfo']; ?></td>
            <td><?php echo $row['actionTaken']; ?></td>
            <td><?php echo $row['policeOfficerName']; ?></td>
            <td><?php echo $row['station']; ?></td>
            <td><?php echo $row['designation']; ?></td>
            <td><?php echo $row['status']; ?></td>
        </tr>
        <?php
        }
        ?>
    </table>
</body>
</html>

<?php
// Close connection
$conn->close();
?>
