<?php
$host = "localhost";
$dbusername = "root";
$dbpassword = ""; // Assuming empty password
$dbdatabase = "crime_management";

// Create connection
$conn = new mysqli($host, $dbusername, $dbpassword, $dbdatabase);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Assuming you're using POST method to send data
$Name = $_POST['Name'] ?? '';
$Individual_code = $_POST['Individual_code'] ?? '';
$Password = $_POST['Password'] ?? '';

// Prepare SQL statement to prevent SQL injection
$sql = $conn->prepare("INSERT INTO admin_login(Name, Individual_code, Password) VALUES (?, ?, ?)");

// Bind parameters and execute query
$sql->bind_param("sss", $Name, $Individual_code, $Password);

if ($sql->execute()) {
  // Start session
  session_start();
  $_SESSION['username'] = $Name; // Save username in session
  echo "<script>alert('Login successful!'); window.location='adminhome.html';</script>"; // Redirect to admin home page with popup
} else {
  echo "Error: " . $sql->error;
}

// Close connection
$conn->close();
?>
