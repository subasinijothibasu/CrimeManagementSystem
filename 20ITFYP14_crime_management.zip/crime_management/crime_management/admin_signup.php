<?php
$host = "localhost";
$dbusername = "root";
$dbpassword = ""; // Assuming empty password
$dbdatabase = "crime_management";

// Create connection
$conn = new mysqli($host, $dbusername, $dbpassword, $dbdatabase);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Assuming you're using POST method to send data
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';
$individual_code = $_POST['individual_code'] ?? '';

// Prepare SQL statement to prevent SQL injection
$sql = $conn->prepare("INSERT INTO admin_signup (name, email, password, confirm_password, Individual_code) VALUES (?, ?, ?,?,?)");

// Bind parameters and execute query
$sql->bind_param("sssss", $name, $email, $password,$confirm_password,$individual_code);

if ($sql->execute()) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql->error;
}

// Close connection
$conn->close();
?>
