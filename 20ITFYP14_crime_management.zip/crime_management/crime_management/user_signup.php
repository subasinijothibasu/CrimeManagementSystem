<?php
$host = "localhost";
$dbusername = "root";
$dbpassword = ""; // Assuming empty password
$dbdatabase = "crime_management";

// Create connection
$conn = new mysqli($host, $dbusername, $dbpassword, $dbdatabase);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Assuming you're using POST method to send data
$name = $_POST['name'] ?? '';
$aadhar = $_POST['aadhar'] ?? '';
$email = $_POST['email'] ?? '';
$contact = $_POST['contact'] ?? '';
$address = $_POST['address'] ?? '';
$password = $_POST['password'] ??'';
$confirm_password = $_POST['confirm_password'] ??'';


// Prepare SQL statement to prevent SQL injection
$sql = $conn->prepare("INSERT INTO user_signup (name, aadhar, email, contact, address, password, confirm_password) VALUES (?, ?, ?, ?, ?, ?, ?)");

// Bind parameters and execute query
$sql->bind_param("sssssss", $name, $aadhar, $email,$contact,$address,$password,$confirm_password);

if ($sql->execute()) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql->error;
}

// Close connection
$conn->close();
?>
