<?php
$host = "localhost";
$dbusername = "root";
$dbpassword = ""; // Assuming empty evidence
$dbdatabase = "crime_management";

// Create connection
$conn = new mysqli($host, $dbusername, $dbpassword, $dbdatabase);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Assuming you're using POST method to send data
$caseNumber = $_POST['caseNumber'] ?? '';
$policeStation = $_POST['policeStation'] ?? '';
$evidence = $_POST['evidence'] ?? '';
$imageUpload = $_POST['imageUpload'] ?? '';
$videoUpload = $_POST['videoUpload'] ?? '';
$additionalInfo = $_POST['additionalInfo'] ?? '';
$actionTaken = $_POST['actionTaken'] ?? '';
$policeOfficerName = $_POST['policeOfficerName'] ?? '';
$station = $_POST['station'] ?? '';
$designation = $_POST['designation'] ?? '';
$status = $_POST['status'] ?? '';


// Prepare SQL statement to prevent SQL injection
$sql = $conn->prepare("INSERT INTO action_taken (caseNumber, policeStation, evidence, imageUpload, videoUpload, additionalInfo, actionTaken, policeOfficerName, station, designation, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

// Bind parameters and execute query
$sql->bind_param("sssssssssss", $caseNumber, $policeStation, $evidence,$imageUpload,$videoUpload,$additionalInfo,$actionTaken,$policeOfficerName,$station,$designation,$status);

if ($sql->execute()) {
  // If the submission is successful, display a JavaScript alert and redirect the user to the reports page
  echo "<script>alert('Report submitted!!'); window.location.href = 'reports.php';</script>";
} else {
  echo "Error: " . $sql->error;
}

// Close connection
$conn->close();
?>
